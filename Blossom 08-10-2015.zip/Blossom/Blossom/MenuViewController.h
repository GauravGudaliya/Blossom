//
//  MenuViewController.h
//  Blossom
//
//  Created by Krunal Kevadiya on 9/25/15.
//  Copyright (c) 2015 Hype Ten. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tblMenu;
@property (weak, nonatomic) IBOutlet UIImageView *ivProfilePic;
@end
