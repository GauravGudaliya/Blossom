//
//  PrivacyController.h
//  Blossom
//
//  Created by Krunal Kevadiya on 10/6/15.
//  Copyright (c) 2015 Hype Ten. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Header.h"
@interface PrivacyController : UIViewController

@end
