//
//  EditProfileViewController.h
//  Blossom
//
//  Created by Krunal Kevadiya on 9/28/15.
//  Copyright (c) 2015 Hype Ten. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditProfileViewController : UIViewController

@end
