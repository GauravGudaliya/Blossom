//
//  OrderHistoryCell.m
//  Blossom
//
//  Created by Krunal Kevadiya on 10/4/15.
//  Copyright (c) 2015 Hype Ten. All rights reserved.
//

#import "OrderHistoryCell.h"

@implementation OrderHistoryCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
