//
//  SideBarController.h
//  Blossom
//
//  Created by Krunal Kevadiya on 9/25/15.
//  Copyright (c) 2015 Hype Ten. All rights reserved.
//
//www.selfcare.mts.india.in

#import <UIKit/UIKit.h>
#import "Header.h"

@interface SideBarController : RESideMenu <RESideMenuDelegate>

@end
