//
//  IntroCell.m
//  KindVisitor
//
//  Created by Darshan Patel on 04/09/15.
//  Copyright (c) 2015 Darshan Patel. All rights reserved.
//

#import "IntroCell.h"

@implementation IntroCell

@end
